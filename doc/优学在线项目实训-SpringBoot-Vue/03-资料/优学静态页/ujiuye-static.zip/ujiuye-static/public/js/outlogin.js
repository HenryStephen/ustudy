/* 
	confing url
 */
function outlogin($site, $flag, $type, $jump){
    window.location.href = "/foreuser/outlogin/";
}